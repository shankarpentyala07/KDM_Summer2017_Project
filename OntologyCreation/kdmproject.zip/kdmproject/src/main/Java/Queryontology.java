/**
 * Created by shankar pentyala on 24-07-2017.
 */
public class Queryontology {
}
